import { Component, OnInit } from '@angular/core';
import { DataService, Digimon } from '../services/data';

export type SortBy = 'name' | 'level';
export type SortOrder = 'asc' | 'desc';

const LEVEL_ORDER: Record<string, number> = {
  'digitama': 0,
  'digihuevo': 0,
  'fresh': 1,
  'baby i': 1,
  'en entrenamiento i': 1,
  'in training': 2,
  'baby ii': 2,
  'en entrenamiento ii': 2,
  'rookie': 3,
  'child': 3,
  'principiante': 3,
  'infantil': 3,
  'champion': 4,
  'adult': 4,
  'campeón': 4,
  'maduro': 4,
  'ultimate': 5,
  'perfect': 5,
  'perfeccionado': 5,
  'megacampeón': 5,
  'mega': 6,
  'supremo': 6,
  'hipercameón': 6,
  'ultra': 7,
  'super ultimate': 7,
  'burst mode': 7,
  'súper supremo': 7,
  'armor': 8,
  'híbrido de armadura': 8,
  'hybrid': 9,
  'spirit': 9,
  'híbrido': 9,
};

function getLevelRank(level: string): number {
  const key = level.toLowerCase().trim();
  return LEVEL_ORDER[key] ?? 99;
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false,
})
export class HomePage implements OnInit {
  digimons: Digimon[] = [];
  filteredDigimons: Digimon[] = [];
  isLoading = true;
  searchTerm = '';
  sortBy: SortBy | null = null;
  sortOrder: SortOrder = 'asc';

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    this.loadDigimons();
  }

  loadDigimons(): void {
    this.isLoading = true;
    this.dataService.getDigimons().subscribe({
      next: (data) => {
        this.digimons = data;
        this.applyFilters();
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      },
    });
  }

  filterDigimons(event: any): void {
    this.searchTerm = event.target.value?.toLowerCase().trim() || '';
    this.applyFilters();
  }

  setSortBy(field: SortBy): void {
    if (this.sortBy === field) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortBy = field;
      this.sortOrder = 'asc';
    }
    this.applyFilters();
  }

  clearSort(): void {
    this.sortBy = null;
    this.applyFilters();
  }

  private applyFilters(): void {
    let result = [...this.digimons];

    if (this.searchTerm) {
      result = result.filter((digimon) =>
        digimon.name.toLowerCase().includes(this.searchTerm)
      );
    }

    if (this.sortBy) {
      result.sort((a, b) => {
        if (this.sortBy === 'name') {
          const comparison = a.name.localeCompare(b.name);
          return this.sortOrder === 'asc' ? comparison : -comparison;
        }
        const comparison = getLevelRank(a.level) - getLevelRank(b.level);
        return this.sortOrder === 'asc' ? comparison : -comparison;
      });
    }

    this.filteredDigimons = result;
  }

  handleRefresh(event: any): void {
    this.dataService.getDigimons().subscribe({
      next: (data) => {
        this.digimons = data;
        this.applyFilters();
        event.target.complete();
      },
      error: () => {
        event.target.complete();
      },
    });
  }
}
