import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService, Digimon } from '../services/data';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
  standalone: false,
})
export class DetailPage implements OnInit {
  digimon: Digimon | null = null;
  isLoading = true;

  constructor(
    private route: ActivatedRoute,
    private dataService: DataService
  ) {}

  ngOnInit(): void {
    const name = this.route.snapshot.paramMap.get('name') || '';
    this.loadDigimonDetail(name);
  }

  private loadDigimonDetail(name: string): void {
    this.isLoading = true;
    this.dataService.getDigimonByName(name).subscribe({
      next: (data) => {
        this.digimon = data[0] || null;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      },
    });
  }
}
