import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

export interface Digimon {
  name: string;
  img: string;
  level: string;
}

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private readonly apiUrl = 'https://digimon-api.vercel.app/api/digimon';

  constructor(private http: HttpClient) {}

  getDigimons(): Observable<Digimon[]> {
    return this.http.get<Digimon[]>(this.apiUrl).pipe(
      catchError((error) => {
        console.error('Error fetching digimons:', error);
        return throwError(() => new Error('Failed to fetch digimons'));
      })
    );
  }

  getDigimonByName(name: string): Observable<Digimon[]> {
    return this.http.get<Digimon[]>(`${this.apiUrl}/name/${name}`).pipe(
      catchError((error) => {
        console.error('Error fetching digimon detail:', error);
        return throwError(() => new Error('Failed to fetch digimon detail'));
      })
    );
  }
}
